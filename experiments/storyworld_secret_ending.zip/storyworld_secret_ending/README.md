# Storyworld Secret Ending Experiment

Minimal, runnable harness to train and evaluate an HRM on secret-ending discovery within a turn budget.

## Quick Start
Run from `C:\projects\HRM-re\experiments\storyworld_secret_ending`:

```
python -m pip install -e ..\..

python .\make_dataset.py --storyworld .\data\mihna_min_storyworld.json --target_ending_id ending_secret_created_quran_accepted --out .\data\mihna_min_dataset.jsonl --episodes 500 --max_turns 10

python .\train_hrm_storyworld.py --data .\data\mihna_min_dataset.jsonl --out .\models\hrm_mihna_min.pt --epochs 3 --batch_size 16 --lr 2e-4 --dim 128

python .\eval_storyworld.py --storyworld .\data\mihna_min_storyworld.json --target_ending_id ending_secret_created_quran_accepted --max_turns 10 --episodes 200 --hrm_model .\models\hrm_mihna_min.pt --report .\reports\results.json --gpt_mock
```

## Outputs
- Dataset: `experiments/storyworld_secret_ending/data/mihna_min_dataset.jsonl`
- Model: `experiments/storyworld_secret_ending/models/hrm_mihna_min.pt`
- Report: `experiments/storyworld_secret_ending/reports/results.json`

## Notes / TODOs
- GPT-5.2 mini: implement API call in `experiments/storyworld_secret_ending/baselines/baseline_gpt52mini.py` (currently mock-only).
- Tiny open model: replace stub logic in `experiments/storyworld_secret_ending/baselines/baseline_tiny_open.py` with a real local model if/when weights are available.
