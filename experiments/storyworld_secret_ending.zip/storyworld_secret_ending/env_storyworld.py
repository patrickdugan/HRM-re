import json
import random
import re
from dataclasses import dataclass


COND_ALLOWED_RE = re.compile(r"^[A-Za-z0-9_ ()<>=!&|.+-]*$")


def _normalize_condition(cond):
    if cond is None:
        return ""
    text = cond.strip()
    if not text:
        return ""
    text = re.sub(r"\bAND\b", "and", text, flags=re.IGNORECASE)
    text = re.sub(r"\bOR\b", "or", text, flags=re.IGNORECASE)
    text = re.sub(r"\btrue\b", "True", text, flags=re.IGNORECASE)
    text = re.sub(r"\bfalse\b", "False", text, flags=re.IGNORECASE)
    return text


def _safe_eval_condition(cond, visible_vars, hidden_vars):
    normalized = _normalize_condition(cond)
    if not normalized:
        return True
    if not COND_ALLOWED_RE.match(normalized):
        raise ValueError(f"Unsafe condition: {cond}")
    context = {}
    context.update(visible_vars)
    context.update(hidden_vars)
    try:
        return bool(eval(normalized, {"__builtins__": {}}, context))
    except Exception as exc:
        raise ValueError(f"Failed to evaluate condition '{cond}': {exc}")


@dataclass
class StepResult:
    obs: dict
    reward: float
    done: bool
    info: dict


class StoryworldEnv:
    def __init__(self, storyworld_path, target_ending_id, max_turns=10):
        with open(storyworld_path, "r", encoding="utf-8") as f:
            self.storyworld = json.load(f)
        self.target_ending_id = target_ending_id
        self.max_turns = max_turns
        self.nodes = {node["id"]: node for node in self.storyworld["nodes"]}
        self.endings = self.storyworld.get("endings", [])
        self._rng = random.Random()
        self.reset()

    def reset(self, seed=None):
        if seed is not None:
            self._rng.seed(seed)
        self.turn = 0
        self.node_id = self.storyworld["nodes"][0]["id"]
        self.visible_vars = {
            name: spec["start"] for name, spec in self.storyworld["variables"].items()
        }
        self.hidden_vars = {
            name: spec.get("start", False)
            for name, spec in self.storyworld.get("hidden_variables", {}).items()
        }
        return self._make_obs()

    def _make_obs(self):
        node = self.nodes[self.node_id]
        return {
            "node_id": node["id"],
            "node_text": node["text"],
            "choices": [{"id": c["id"], "text": c["text"]} for c in node["choices"]],
            "visible_vars": dict(self.visible_vars),
            "turns_left": self.max_turns - self.turn,
        }

    def _apply_effects(self, effects):
        if not effects:
            return
        for key, delta in effects.items():
            if key not in self.visible_vars:
                continue
            spec = self.storyworld["variables"][key]
            new_val = self.visible_vars[key] + delta
            self.visible_vars[key] = max(spec["min"], min(spec["max"], new_val))

    def _apply_hidden_effects(self, effects):
        if not effects:
            return
        for key, val in effects.items():
            if key not in self.hidden_vars:
                continue
            self.hidden_vars[key] = bool(val)

    def _check_endings(self):
        for ending in self.endings:
            if ending["node_id"] != self.node_id:
                continue
            if _safe_eval_condition(ending.get("condition", ""), self.visible_vars, self.hidden_vars):
                return ending
        return None

    def step(self, choice_id):
        node = self.nodes[self.node_id]
        choice = None
        for c in node["choices"]:
            if c["id"] == choice_id:
                choice = c
                break
        if choice is None:
            raise ValueError(f"Invalid choice_id '{choice_id}' for node '{self.node_id}'")

        self.turn += 1
        self._apply_effects(choice.get("effects", {}))
        self._apply_hidden_effects(choice.get("hidden_effects", {}))
        self.node_id = choice["to"]

        ending = self._check_endings()
        done = False
        reward = -1.0
        info = {
            "ending_id": None,
            "ending_type": None,
            "target_hit": False,
        }

        if ending is not None:
            done = True
            info["ending_id"] = ending["id"]
            info["ending_type"] = ending["type"]
            reward += 10.0
            if ending["id"] == self.target_ending_id:
                reward += 100.0
                info["target_hit"] = True
            elif ending["type"] == "normal":
                reward -= 5.0

        if self.turn >= self.max_turns and not done:
            done = True
            info["ending_id"] = None
            info["ending_type"] = None

        obs = self._make_obs()
        return StepResult(obs=obs, reward=reward, done=done, info=info)

    def sample_choice(self):
        node = self.nodes[self.node_id]
        return self._rng.choice(node["choices"])["id"]

    def available_choices(self):
        node = self.nodes[self.node_id]
        return [c["id"] for c in node["choices"]]

    def get_node(self):
        return self.nodes[self.node_id]


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--storyworld", required=True)
    parser.add_argument("--target_ending_id", required=True)
    parser.add_argument("--max_turns", type=int, default=10)
    args = parser.parse_args()

    env = StoryworldEnv(args.storyworld, args.target_ending_id, max_turns=args.max_turns)
    obs = env.reset(seed=0)
    print(json.dumps(obs, indent=2))
