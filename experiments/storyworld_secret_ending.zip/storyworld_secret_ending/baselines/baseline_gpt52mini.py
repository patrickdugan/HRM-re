import os
import random


def choose_action(obs, api_key=None, mock=True, rng=None):
    rng = rng or random.Random(0)
    if api_key is None:
        api_key = os.environ.get("GPT52MINI_API_KEY")

    if api_key and not mock:
        # TODO: Replace with real API call.
        # - Build a prompt from obs
        # - Call GPT-5.2 mini
        # - Parse a valid choice_id from the response
        raise NotImplementedError("GPT-5.2 mini API call not implemented. Use mock mode or add implementation.")

    # Deterministic mock policy
    vars_map = obs.get("visible_vars", {})
    rationality = vars_map.get("rationality", 50)
    favor = vars_map.get("favor", 50)
    suspicion = vars_map.get("suspicion", 50)

    for choice in obs["choices"]:
        text = choice["text"].lower()
        if "pact" in text:
            return choice["id"]

    if favor < 70:
        for choice in obs["choices"]:
            if "patron" in choice["text"].lower():
                return choice["id"]

    if rationality < 80:
        for choice in obs["choices"]:
            if "study" in choice["text"].lower() or "argument" in choice["text"].lower():
                return choice["id"]

    if suspicion > 60:
        for choice in obs["choices"]:
            if "withdraw" in choice["text"].lower() or "discreet" in choice["text"].lower():
                return choice["id"]

    return rng.choice(obs["choices"])["id"]


if __name__ == "__main__":
    demo_obs = {
        "choices": [
            {"id": "c1", "text": "Accept a risky pact."},
            {"id": "c2", "text": "Study at the academy."}
        ],
        "visible_vars": {"rationality": 60, "favor": 40, "suspicion": 20},
    }
    print(choose_action(demo_obs))
