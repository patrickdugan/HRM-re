import argparse
import json
import random
from datetime import datetime

from env_storyworld import StoryworldEnv


TARGET_SCORE = {
    "rationality": 1.0,
    "favor": 1.0,
    "suspicion": -1.2,
}


def _choice_score(choice):
    score = 0.0
    for key, weight in TARGET_SCORE.items():
        score += weight * choice.get("effects", {}).get(key, 0)
    return score


def secret_policy(env, obs):
    node = env.get_node()
    if not env.hidden_vars.get("risky_pact", False):
        for c in node["choices"]:
            if c.get("hidden_effects", {}).get("risky_pact") is True:
                return c["id"], "Trigger risky pact, then build favor and rationality."

    if env.node_id == "hall_of_judgment":
        return "seek_patron_support", "Increase favor and keep suspicion low."

    # If already strong, aim for judgment
    if env.hidden_vars.get("risky_pact", False):
        if env.visible_vars["rationality"] >= 80 and env.visible_vars["favor"] >= 70 and env.visible_vars["suspicion"] <= 45:
            for c in node["choices"]:
                if c["to"] == "hall_of_judgment":
                    return c["id"], "Move to judgment with strong stats."

    best = max(node["choices"], key=_choice_score)
    return best["id"], "Optimize rationality and favor while reducing suspicion."


def normal_policy(env, obs):
    node = env.get_node()
    # Prefer routes to tribunal or exile if they exist
    for c in node["choices"]:
        if c["to"] in ("tribunal", "exile_gate"):
            return c["id"], "Force a normal ending quickly."

    def score(choice):
        return choice.get("effects", {}).get("suspicion", 0) - choice.get("effects", {}).get("favor", 0)

    best = max(node["choices"], key=score)
    return best["id"], "Increase suspicion or reduce favor to trigger normal ending."


def random_policy(env, obs):
    return env.sample_choice(), "Explore randomly to induce timeouts."


def run_episode(env, policy_fn):
    obs = env.reset(seed=env._rng.randint(0, 1_000_000))
    steps = []
    done = False
    while not done:
        action, plan = policy_fn(env, obs)
        result = env.step(action)
        steps.append({
            "t": len(steps),
            "obs": obs,
            "action": action,
            "plan": plan,
            "outcome": {
                "next_node_id": result.obs["node_id"],
                "visible_vars": result.obs["visible_vars"],
                "done": result.done,
                "ending_id": result.info["ending_id"],
            },
        })
        obs = result.obs
        done = result.done
    return steps, result.info


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--storyworld", required=True)
    parser.add_argument("--target_ending_id", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--episodes", type=int, default=500)
    parser.add_argument("--max_turns", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    env = StoryworldEnv(args.storyworld, args.target_ending_id, max_turns=args.max_turns)
    env._rng = rng

    target_success = int(args.episodes * 0.3)
    target_normal = int(args.episodes * 0.3)
    target_timeout = args.episodes - target_success - target_normal

    counts = {"success": 0, "normal": 0, "timeout": 0}

    with open(args.out, "w", encoding="utf-8") as f:
        attempts = 0
        while sum(counts.values()) < args.episodes and attempts < args.episodes * 20:
            attempts += 1
            if counts["success"] < target_success:
                policy = secret_policy
                expected = "success"
            elif counts["normal"] < target_normal:
                policy = normal_policy
                expected = "normal"
            else:
                policy = random_policy
                expected = "timeout"

            steps, info = run_episode(env, policy)
            category = "timeout"
            if info["ending_id"] is not None:
                if info.get("target_hit"):
                    category = "success"
                else:
                    category = "normal"

            if category != expected:
                continue

            episode_id = f"ep_{sum(counts.values()):05d}"
            record = {
                "episode_id": episode_id,
                "target_ending_id": args.target_ending_id,
                "max_turns": args.max_turns,
                "steps": steps,
            }
            f.write(json.dumps(record) + "\n")
            counts[category] += 1

    summary = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "counts": counts,
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
